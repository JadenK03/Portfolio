<div id="source">
<h2>Sides</h2>

<h3 id="item7" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="11.99" >Broccolini Salad</h3>
<p>This crunchy broccolini salad mixed with caramelised roasted garlic together with a sweet-savoury dressing</p>
<p>$11.99</p>

<h3 id="item8" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="9.99" >Lod Chong</h3>
<p>A Thai dessert with rice flour and sliced melon in coconut milk</p>
<p>$9.99</p>

<h3 id="item9" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="15.99" >Tiny Truffled Hasselback Potatoes</h3>
<p>Once roasted with some olive oil, they are covered in truffle butter and truffle salt.</p>
<p>$15.99</p>
</div>