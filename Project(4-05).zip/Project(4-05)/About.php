<?php 

// include the common functions
require "include.inc";

// start the html code
HTMLStart( "About Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
?>
	<!--About Contents -->
	<main class="main text-center">
	<section class="map-grid">
	<!--Sidebar/Aside -->
	<div class="abtsidebar ">
		<h2>View our location</h2>
		<a href="Map.php">Location</a>
		<p>Be ready for the most fun and over-the-top restaurant search you've ever experienced! We look forward to meeting you soon!</p>
		<img src="skull.webp">
	</div>
		
	<!--Contents -->
	<div class="abtp abtcontent">
		<h1 >About Our Restaurant</h1>
		<p >We are a locally-owned, family-owned restaurant that has been serving delicious food to our community for over 20 years. 
			Our menu features a variety of dishes that are made with fresh, locally-sourced ingredients 
			(without those pesky guidelines from the FDA and DOA). From hearty breakfasts to satisfying lunches and dinners, 
			we have something for everyone. With a C in our health and safety grade, you know the food at least has to be good!</p>
		<p >We pride ourselves on providing excellent service and creating a welcoming atmosphere for our guests. 
			Whether you're dining in or ordering takeout, we want you to have a memorable experience with us.
			Thats why our fire-breathing performer Hans will always be putting on a show for our customers.
			Hans has only burned 4 customers in the past month and he is improving day by day.</p>
		<p >Visit us today to taste the difference that quality ingredients, passion, and a little bit of spit n' elbow grease, can make. 
			We look forward to serving you, your friends, and family soon!</p>
			
		<!--Image -->
		<img class="abtp-img" src="family-img.jpg" alt="Our family">
		<p>This is a photo of our founding family with our "face-camping" chef Bubba on the left</p>
	</div>
	</main>
<?php

// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
