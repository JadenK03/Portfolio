<div id="source">
<h2>Drinks</h2>

<h3 id="item10" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="2.99" >Soft Drinks</h3>
<p>Lemon-lime Drinks, Orange Soda, Cola, Grape Soda, Ginger Ale, and Root Beer</p>
<p>$2.99</p>


<h3 id="item11" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="9.99" >Coctails</h3>
<p>$7.99 - $11.99</p>


<h3 id="item12" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="6.99" >Assorted Beers</h3>
<p>Budweiser, Bud Light, Corona, Heineken, Coors Light, Tsingtao, Modelo, Miller Lite, Guinness, and Sapporo</p>
<p>$4.99 - $9.99</p>

</div>