// using lab j4's js code to get an idea of how we can switch the menus in the cart
//we will be changing this to access separate html files for drinks,entrees,etc 
//similar to the logans run/soylent green html files
//more ids need to be changed for each function
//this will be the function to change menus
function GetMenu(Category, OutputID)
{
    // declare local variables
    var xmlhttp;

    // create the request object depending on
    //      the browser type
    if ( window.XMLHttpRequest )
    {
        // code for IE7+, Firefox, Chrome, Safari, Opera
        xmlhttp = new XMLHttpRequest;
    }
    else
    {
        // code for IE6 and earlier - need to use an
        //      ActiveX object (yuck!)
        xmlhttp = new ActiveXObject( "Microsoft.XMLHTTP" );
    }

    // set the callback function. this function inserts the html that
    //      is received into the "info" section of the page. It is
    //      a callback function because the XMLHttpRequest object
    //      calls this function when the ready state changes and it
    //      is provided by the user of the object.
    xmlhttp.onreadystatechange = function ()
    {
        // check for a good return
        if (( xmlhttp.readyState == 4 ) &&
            ( xmlhttp.status == 200 ))
        {
            // add the received html to the info section
            document.getElementById( OutputID ).innerHTML = xmlhttp.responseText;
        }
    }


    // create the request. this creates a HTTP POST request
    //      POST requests are better then GET requests. when you start
    //      to pass parameters as part of the request, POST puts them
    //      in the content of the HTTP packet. this makes it harder to
    //      snoop stuff and when using https, the contents are encrypted.
    xmlhttp.open( "POST", "Cart.php", true );

    // this set the content of the http pack mime type so that PHP can
    //      process it correctly
    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");

    // build a string of anything you want to pass
    //      the syntax is <name>=<value> for example:
    //
    //              course=COMP205
    //
    //      to pass more than one, separate them with a ?. for example:
    //
    //              course=COMP205?section=01
    //
    //      for this application there is only one thing to pass. it will
    //      either be this:
    //
    //              Continent=North America
    //
    //      or
    //
    //              Contient=South America
    //
    var Argument = "Category=" + Category;

    // send the request to the server
    //      pass the argument now
    xmlhttp.send( Argument );
}


//we can implement the drag and drop code from lab j5 to move menu items into the list
// start drag of item
//      pass in the event that is triggering
//      the drag
function StartDrag( CurrentEvent )
{
    // sets the data type using MIME (first argument)
    //      sets the source of the data (second argument)
    //      the second argument is why the draggable items
    //      need a unique id
    CurrentEvent.dataTransfer.setData( "text/html", CurrentEvent.target.id );
}

// allow a drop into the element
function AllowDrop( CurrentEvent )
{
    // prevent the browser from handling the event
    //      with its default handling. the default
    //      is to not allow drag and drop. 
    CurrentEvent.preventDefault();
}

// handle dropping here
function Drop( CurrentEvent )
{
    // this creates a variable called data
    //      and initializes it in the same statement.
    //      it gets the ID of the element that is being dragged.
    var DataID = CurrentEvent.dataTransfer.getData( "text/html" );
   
   var Item = document.querySelector( "div[id=\"source\"] h3[id=\"" + DataID + "\"]");
   var ItemPrice = Item.getAttribute( "data-point-value" );

    console.log(DataID)

  
    
    // get the existing item in the calculator
    var DestinationTotal = document.querySelector( "div[id=\"cartlist\"] h3[id=\"" + DataID + "\"]" );


    // check for no item found
    if ( null == DestinationTotal )
    {
    // add a new item
    DestinationTotal = document.createElement( "h3" );

    // set the element attributes
    DestinationTotal.setAttribute( "id", DataID );
    DestinationTotal.setAttribute( "class", "item" );        
    DestinationTotal.setAttribute( "data-point-value", ItemPrice );
    DestinationTotal.setAttribute( "data-count", 1 );

    // add a handler for double clicks
    DestinationTotal.addEventListener( "dblclick", function () { RemoveItem( DataID ); } );

    // add the text for the item in the calculator
    DestinationTotal.innerHTML = Item.innerHTML;

    // add the element to the destination div
    document.querySelector( "div[id=\"cartlist\"]" ).appendChild( DestinationTotal );
    }

    else
    {
    // update existing item 
    var Count = Number( DestinationTotal.getAttribute( "data-count" )) + 1;
    DestinationTotal.setAttribute( "data-count", Count );
    DestinationTotal.innerHTML = Item.innerHTML + "<br />(" + Count + ")";

    }

    // prevent the default handling which is to
    //      not allow dropping
    CurrentEvent.preventDefault();

   
    ComputeTotal()
}




function RemoveItem(DataID)
{
    
    // prompt the user
    var Result = window.confirm( "Remove the Item?" );

    // process based on the result
    if ( Result == true )
    {
    // get the existing grade in the calculator
    var DestinationTotal = document.querySelector( "div[id=\"cartlist\"] h3[id=\"" + DataID + "\"]" );

    // drop the count down by one
    var Count = Number( DestinationTotal.getAttribute( "data-count" )) - 1;
    }

    // see if it is the last
    if ( 0 == Count )
    {
    // remove the node
    DestinationTotal.parentNode.removeChild( DestinationTotal );
    }

    else
    {

    // update the count
   // DestinationTotal.setAttribute( "data-count", Count );
   // DestinationTotal.innerHTML = Item.innerHTML + "<br />(" + Count + ")";
    

    //make a variable
    //search for a br
    //take a subsstring of everything before the br
    //add on the new count

    // update the count
    DestinationTotal.setAttribute("data-count", Count);

    // make a variable
    var itemText = DestinationTotal.innerHTML;

    // search for a br
    var brIndex = itemText.indexOf('<br>');

    if (brIndex >= 0) 
    {
    // take a substring of everything before the br
    var itemNameOnly = itemText.substring(0, brIndex);

    // add on the new count
    DestinationTotal.innerHTML = itemNameOnly + "<br />(" + Count + ")";
    }
    }
    //call
    ComputeTotal()
    
}

function ComputeTotal()
{
    //here we can add an equation after applying price values to the menu items

    // get the list of menu
    var Items = document.querySelectorAll( "div[id=\"cartlist\"] h3" );

    // update the total points and number of grades
  
    var total = 0
    var count = 0
    for (var i = 0; i <Items.length; i++)
    {
         total += (Items[i].getAttribute( "data-point-value" )) * (Items[i].getAttribute ("data-count"));
         count += Number(Items[i].getAttribute( "data-count" ));
       
    }

  
    // update the GPA display on the page
    document.querySelector("div[id='destination']+ p ").innerHTML = "Your Total Price is: $" + total.toFixed(2);
    
}

