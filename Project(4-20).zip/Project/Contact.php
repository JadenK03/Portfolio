<?php 

// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Contact Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
?>
    <!--Main Contents -->
	<!--Contact Info-->
	<main class="main text-center">
	<section class="contact-grid">
		<aside class="sidebar">
			<img src="callus.jpg" />
		</aside>
	
    <section class="contact-main",>
		<h1 >How to Contact us</h1>
		<p >Phone: Dive n Drink (348-363-7465)</p>
		<p >Email: Dive&Drink@justshowupandeat.com</p>
		<p >Feel free to call ahead to place an order or make a reservation!</p>
	</section>
		
    <aside class="sidebar2">
		<img src="callus2.png" />
	</aside>
	
    </section>
	</main>
<?php

// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
