
<?php 



// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Cart Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
?>
    <!--Main Contents -->
	<main class="main text-center">
    <section class="cart-grid">
  
    <div class="catg main-cart">
    <div class="menu-section">
    <h2>Select Categories</h2>  
        <div class="menu-items " id="menu-1">
        <button class="item text-center" onclick="GetMenu( 'results', 'Appetizer' );">Appetizer</button>
          
        <button class="item text-center" onclick="GetMenu( 'results', 'Main Menu' );">Main Menu</button>
          
        <button class="item text-center" onclick="GetMenu( 'results', 'Sides' );">Sides</button>
          
        <button class="item text-center" onclick="GetMenu( 'results', 'Drinks' );">Drinks</button>
        </div>
    </div>
    </div>

    <!--main cart for selecting the categorys -->
    <div class="main cart-section"  id="result">
        <h2>Select Your Categories!</h2>
    </div>
    
    <!--cart layout -->
    <div class="cart cart-section">
        <h2>Cart</h2>
         
        <!-- item list -->
        <div id="cartlist" class="listbox" ondragover="AllowDrop( event );" ondrop="Drop( event, 'cartlist' );"> </div>   
          
        <div id="destination"> </div>
        <p>Your Total Price is:</p>
    </div>
    </section>
    </main>
<?php

// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>



