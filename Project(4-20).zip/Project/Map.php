<?php 

// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Map Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
?>
    <!--Main Contents -->
	<main class="main text-center">
    <section class="map-grid">
    
    <!--Sidebar/Aside -->
    <div class="abtsidebar">
		<h2>View some info about us</h2>
		<a href="About.php" style="color: white;">About Us</a>
        <p>We have put together a comprehensible page to help you have a quick rundown of our restaurant. Any further questions will
        gladly be answered in person!</p>
        <img src="info.png">
    </div>

    <!--Contents -->
    <div class="abtcontent">
		<h1>Where to find us</h1>
		<p class="abtp">Finding our restaurant is a walk in the park! (if you know the right people) We are located just off of
        the exit towards Lock Haven from interstate 80. Our location may look abandoned but thats because the real restaurant
        lies below the abandoned gas station. Follow the scavenger hunt left on the counter and it will lead to to the secret
        password to enter our top secret sub-terrainian restaurant.</p>
	
    	<p class="abtp">After you complete the super-secret-ultra-hard scavenger hunt come back to our location and, while standing
        in the middle of the dusty, abandoned room, scream the pass phrase as loud as possible. One of our founding family members
        will then allow you to enter the restaurant and help us treat you to the finest dining this side of the interstate.</p>
		<p class="abtp">We look forward to letting you join our family soon!</p>

    <!--Map -->
		<div class="map-center">
        <div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3">
        <div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div><script>(function () {
        var setting = {"height":450,"width":706,"zoom":18,"queryString":"548 S Heckmans Gap Rd, Mill Hall, PA 17751, USA","place_id":"ChIJs-CuHzjuzokRU07-bVX_ZTk","satellite":true,"centerCoord":[41.05325532934474,-77.43537138524829],"cid":"0x3965ff556dfe4e53","lang":"en","cityUrl":"/us/pa/centre-hall-62472","cityAnchorText":"Map of Centre Hall, Pennsylvania, United States","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"880459"};
        var d = document;
        var s = d.createElement('script');
        s.src = 'https://1map.com/js/script-for-user.js?embed_id=880459';
        s.async = true;
        s.onload = function (e) {
        window.OneMap.initMap(setting)
        };
        var to = d.getElementsByTagName('script')[0];
        to.parentNode.insertBefore(s, to);
        })();</script><a href="https://1map.com/map-embed">1 Map</a></div>
        <p>Please find the scavenger hunt after arriving at our address marked on this map for your convenience.</p>			
        </div>
        </div>
     </section>
    </main> 
<?php

// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
