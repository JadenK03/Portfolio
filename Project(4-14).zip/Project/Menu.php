<?php 

//Database Connection info
//Make sure to enter your username and password
$Server = "151.161.91.21";
$UserName = "pdj1404";
$Password = "AgentMikaela69";
$Database = "Group4_COMP205_Sp23";

//connect to DB
$Connection = new mysqli( $Server, $UserName, $Password, $Database );

// check for a successful connection
//      connect_error will evaluate to true if there is an error
if ( $Connection->connect_error )
{
    // stop the script and echo an error message
    echo "<h2>Database Error</h2>\n";
    die( "MySQLi Connection Error: ".$Connection->connect_error."\n" );
}

// make a select statement to get data from the database
$SQL = "select id, category, name, description, price from menu;";
       
// execute the query
//      use the query method of the $Connection object
$Results = $Connection->query( $SQL );
        
// check for results
//      $Results will evaluate to true if there data is returned
//      from the database, false if no data is returned
if ( $Results )
{
// results returned
echo "<p>Results returned from the query</p>\n";            

// start the table HTML
echo "<table>\n";

// add the HTML for a table header row
echo "   <thead>\n";
echo "      <th>ID</th>\n";
echo "      <th>Category</th>\n";
echo "      <th>Name</th>\n";
echo "      <th>Description</th>\n";
echo "      <th>Price</th>\n";
echo "   </thead>\n";

// loop through the results
//      the fecth_row method returns an array of the column
//      data - one item in the array for each column in the
//      select statement.
//
//      the statement in the while will evaluate to false when
//      there are no more rows
while( $Row = $Results->fetch_row() )
{
// add  table row
echo "   <tr>\n";


// loop through the items in the array
//      the count function returns the number of items
//      in the array.
for( $i=0; $i<count($Row); $i++ )
{  
    // add table cells
    echo "     <td>".$Row[$i]."</td>\n";
}

// end of the table row
echo "   </tr>\n";

}

}

else
{
	// no results returned
	echo "<p>No results returned from the query</p>\n";
}

// close the connection
$Connection->close();
//end database connection


// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Menu Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
?>
    <!--Main Contents -->
	<main class="main text-center">
	<section class="menu-grid">
		
        <!--Menu layout-->
		<h1 class="menu">Our Menu</h1>

		<h2 class="appetizer">Appetizer</h2>

		<div class="item1">
			<img src="app1.webp">
			<h3>Slow-Roasted Cherry Tomato Bruschetta</h3>
			<p>Tangy goat cheese and crusty French bread come together in perfect harmony with our best-ever homemade bruschetta recipe</p>
			<p>$10.99</p>
		</div>

		<div class="item2">
			<img src="app2.webp">
			<h3>Crab Cake Bites</h3>
			<p>Whisk together eggs, celery, onion, parsley, mayonnaise, mustard, Worcestershire sauce, and Old Bay seasoning </p>
			<p>$12.99</p>
		</div>

		<div class="item3">
			<img src="app3.webp">
			<h3>Cranberry Brie Bites</h3>
			<p>Made with crescent roll dough, brie, cranberry sauce and a sprig of rosemary</p>
			<p>$7.99</p>
		</div>
		
		<h2 class="main-menu">Main Menu</h2>

		<div class="item4">
			<img src="main1.webp">
			<h3>Cedar-Plank Salmon</h3>
			<p>The salmon takes on a light, smoky woodiness from grilling on a cedar plank, for a lovely pairing of earth and ocean</p>
			<p>$17.99</p>
		</div>

		<div class="item5">
			<img src="main2.webp">
			<h3>Braised Chicken Legs With Grapes and Fennel</h3>
			<p>Roasting the grapes concentrated their flavor, making a jammy-sweet accompaniment to the meaty chicken thighs</p>
			<p>$22.99</p>
		</div>

		<div class="item6">
			<img src="main3.webp">
			<h3>Double-Stack Mushroom and Chicken Cheeseburgers</h3>
			<p>These chicken burgers are grilled and finished with gooey Muenster, stacked, and topped with shredded lettuce, sweet pickles, and curry mustard</p>
			<p>$15.99</p>
		</div>

		<h2 class="sides">Sides</h2>

		<div class="item7">
			<img src="side1.jpg">
			<h3>Broccolini Salad</h3>
			<p>This crunchy broccolini salad mixed with caramelised roasted garlic together with a sweet-savoury dressing</p>
			<p>$11.99</p>
		</div>

		<div class="item8">
			<img src="side2.jpg">
			<h3>Lod Chong</h3>
			<p>A Thai dessert with rice flour and sliced melon in coconut milk</p>
			<p>$9.99</p>
		</div>

		<div class="item9">
			<img src="side3.jpg">
			<h3>Tiny Truffled Hasselback Potatoes</h3>
			<p>Once roasted with some olive oil, they are covered in truffle butter and truffle salt.</p>
			<p>$15.99</p>
		</div>

		<h2 class="drinks">Drinks</h2>

		<div class="item10">
			<img src="drink1.jpg">
			<h3>Soft Drinks</h3>
			<p>Lemon-lime Drinks, Orange Soda, Cola, Grape Soda, Ginger Ale, and Root Beer</p>
			<p>$2.99</p>
		</div>

		<div class="item11">
			<img src="drink2.jpg">
			<h3>Coctails</h3>
			<p>$7.99 - $11.99</p>
		</div>

		<div class="item12">
			<img src="drink3.webp">
			<h3>Assorted Beers</h3>
			<p>Budweiser, Bud Light, Corona, Heineken, Coors Light, Tsingtao, Modelo, Miller Lite, Guinness, and Sapporo</p>
			<p>$4.99 - $9.99</p>
		</div>
	</main>
<?php

// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
