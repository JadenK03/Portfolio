
<div id="source">
<h2>Appetizer</h2>

<h3 id="item1" class="item" draggable="true" ondragstart="StartDrag( event );"
    data-point-value="10.99">Slow-Roasted Cherry Tomato Bruschetta</h3>
<p>Tangy goat cheese and crusty French bread come together in perfect harmony with our best-ever homemade bruschetta recipe</p>
<p>$10.99</p>


<h3 id="item2" class="item" draggable="true" ondragstart="StartDrag( event );"
    data-point-value="12.99">Crab Cake Bites</h3>
<p>Whisk together eggs, celery, onion, parsley, mayonnaise, mustard, Worcestershire sauce, and Old Bay seasoning </p>
<p>$12.99</p>


<h3 id="item3" class="item" draggable="true" ondragstart="StartDrag( event );"
    data-point-value="7.99">Cranberry Brie Bites</h3>
<p>Made with crescent roll dough, brie, cranberry sauce and a sprig of rosemary</p>
<p>$7.99</p>
</div>