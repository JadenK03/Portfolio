<div id="source">
<h2>Main Menu</h2>

<h3 id="item4" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="17.99" >Cedar-Plank Salmon</h3>
<p>The salmon takes on a light, smoky woodiness from grilling on a cedar plank, for a lovely pairing of earth and ocean</p>
<p>$17.99</p>

<h3 id="item5" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="22.99" >Braised Chicken Legs With Grapes and Fennel</h3>
<p>Roasting the grapes concentrated their flavor, making a jammy-sweet accompaniment to the meaty chicken thighs</p>
<p>$22.99</p>

<h3 id="item6" class="item" draggable="true" ondragstart="StartDrag( event );"
data-point-value="17.99" > Double-Stack Mushroom and Chicken Cheeseburgers</h3>
<p>These chicken burgers are grilled and finished with gooey Muenster, stacked, and topped with shredded lettuce, sweet pickles, and curry mustard</p>
<p>$15.99</p>
</div>