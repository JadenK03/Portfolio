<?php 

// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Home Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();
// function to write the sidebar
Sidebar();


// write the main section
?>

    <!--Main Contents -->
	<main class="main text-center">
		<h1>Welcome to Our Restaurant</h1>
		<p>Great food, great service, and great atmosphere</p>
		<p>The best in Town!</p>
		<img src="award2.jpg"/> <img src="award1.png"/> <img src="award3.png"/> 
		<h2> Book for Reservation!!!</h2>
	</main>


<?php

// write the page footer
PageFooter();

PageLogin();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
