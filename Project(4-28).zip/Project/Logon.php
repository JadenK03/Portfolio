<?php
    // include common php routines
    require "Include.inc";

    // check for POST variables
if ( isset( $_POST["UserName"] ))
{
    // save the user name and password to the session
    $_SESSION["UserName"] = $_POST["UserName"];
    $_SESSION["Password"] = $_POST["Password"];
    
    // load index pafe
    header( "Location: Index.php" );
    exit();
}

    // set the title
    $Title = "Login Page";
    $Subtitle = "Logon Page";

    // write out the beginning of the web page
    HTMLStart( $Title, "style.css" );

    // write out the header
    PageHeader( $Title, $Subtitle );

    // now the navigation section
    PageNavigation();
?>    

<section>
    <form action="Logon.php" method="POST">
        <p>User Name: <input name="UserName" type="text" required="true" /></p>
        <p>Password: <input name="Password" type="password" required="true" /></p>
        <p><button type="submit">Logon</button></p>
    </form>
</section>

<?php
    // now the page footer
    PageFooter();

    PageLogin();
    
    // write out the end of the web page
    HTMLEnd();
?>
    

    
