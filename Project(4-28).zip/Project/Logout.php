<?php
    //destroying sessions

    // require the lab 21 include
    require "Include.inc";
    
    // log out
    session_destroy();

    // go back to logon page
    header( "Location: Logon.php" );
?>
      