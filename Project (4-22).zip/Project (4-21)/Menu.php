<?php 




// include the common functions
require "Include.inc";

// start the html code
HTMLStart( "Menu Page" );

// start the grid
GridStart();

// write the header section
PageHeader();

// write the navigation section
PageNavigation();

// function to write the sidebar
Sidebar();

// write the main section
InsertMenu();
	


// write the page footer
PageFooter();

// end of the grid container
GridEnd();

// end of the html
HTMLEnd();

?>
   
