<?php
    // include common php routines
    require "Include.inc";

    // Start the session
    session_start();
  
    if (isset($_POST["UserName"])) {
      // Get the user's information from the form
      $username = $_POST["UserName"];
      $password = $_POST["Password"];
  
      // set the connection information
      // 151.161.91.21 is the ip address of the database server
      // set the UserName and Password to your credentials
      // set the database to your username 
      $Server = "151.161.91.21";
      $UserName = "pdj1404";
      $Password = "AgentMikaela69";
      $Database = "Group4_COMP205_Sp23";
  
      // connect to the database
      // create a new instance of a mysqli object. this
      // object contains the connection to the mysql server
      $Connection = new mysqli( $Server, $UserName, $Password, $Database );
  
      // check for a successful connection
      // connect_error will evaluate to true if there is an error
      if ( $Connection->connect_error )
      {
          // stop the script and echo an error message
          echo "<h2>Database Error</h2>\n";
          die( "MySQLi Connection Error: ".$Connection->connect_error."\n" );
      }
  
      $check_user = "SELECT * FROM users WHERE email='$username' AND password='$password'";
      $result = mysqli_query($Connection, $check_user);
  
      if (mysqli_num_rows($result) > 0) {
        // User information is already in the database
        // Save the user name and password to the session
        $_SESSION["UserName"] = $username;
        $_SESSION["Password"] = $password;
  
        // Load index page
        header("Location: Index.php");
        exit();
      } else {
        // User information is not in the database
        echo "Invalid username or password.";
      }
  
      mysqli_close($Connection);
    }

    // set the title
    $Title = "Login Page";
    $Subtitle = "Logon Page";

    // write out the beginning of the web page
    HTMLStart( $Title, "style.css" );

    // write out the header
    PageHeader( $Title, $Subtitle );

    // now the navigation section
    PageNavigation();
?>    
<section>
    <form action="Logon.php" method="POST">
        <p>User Name (email): <input name="UserName" type="email" required="true" /></p>
        <p>Password: <input name="Password" type="password" required="true" /></p>
        <p><button type="submit">Login</button></p>
    </form>
</section>
<?php
    // now the page footer
    PageFooter();

    PageLogin();
    
    // write out the end of the web page
    HTMLEnd();
?> 