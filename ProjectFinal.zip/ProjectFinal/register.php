<?php

// include the common functions
require "Include.inc";

// Get the user's registration information from the form
$email = $_POST["email"];
$password = $_POST["password"];
$fname = $_POST["fname"];
$lname = $_POST["lname"];
$address = $_POST["address"];
$city = $_POST["city"];
$state = $_POST["state"];
$zip = $_POST["zip"];

// write out the beginning of the web page
HTMLStart( $Title, "style.css" );

// write out the header
PageHeader( $Title, $Subtitle );

// now the navigation section
PageNavigation();


//html for registration page
Registration();


  

  //establish DB connection
  $Server = "151.161.91.21";
  $UserName = "pdj1404";
  $Password = "AgentMikaela69";
  $Database = "Group4_COMP205_Sp23";

  $conn = mysqli_connect( $Server, $UserName, $Password, $Database );

  if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
  }

  //check for duplicate email address
  $check_email = "SELECT * FROM users WHERE email='$email'";
  $result = mysqli_query($conn, $check_email);

  if (mysqli_num_rows($result) > 0) {
    die("Email address already in use.");
  }

  $sql = "INSERT INTO users (email, password, fname, lname, address, city, state, zip) VALUES ('$email', '$password', '$fname', '$lname', '$address', '$city', '$state', '$zip')";

  if (mysqli_query($conn, $sql)) {
    // Registration successful
    // Redirect the user to the logon page
    header("Location: Logon.php");
    exit();
  } else {
    echo "Error: " . mysqli_error($conn);
  }

  mysqli_close($conn);
  



   // now the page footer
   PageFooter();

   PageLogin();
   
   // write out the end of the web page
   HTMLEnd();
?>